<!DOCTYPE html>
<html lang="en-US" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">

<head>
    <!-- Google Tag Manager -->
<meta charset="utf-8"><script async>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-PRN6G3K');</script>

<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;700&family=Open+Sans:wght@400;700&display=swap">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geologica:wght@700&display=swap">
<title>404 page - GoodCrypto</title>
<link rel="alternate" hreflang="en" href="https://goodcrypto.app/404-page/" />
<link rel="alternate" hreflang="x-default" href="https://goodcrypto.app/404-page/" />

<meta name="robots" content="index, follow"/>
<link rel="canonical" href="https://goodcrypto.app/404-page/" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="404 page - GoodCrypto" />
<meta property="og:url" content="https://goodcrypto.app/404-page/" />
<meta property="og:site_name" content="GoodCrypto" />
<meta property="article:publisher" content="https://www.facebook.com/GoodCryptoApp" />
<meta property="og:image" content="https://goodcrypto.app/wp-content/uploads/2023/05/photo_2023-05-05_12-14-53.jpg" />
<meta property="og:image:width" content="1280" />
<meta property="og:image:height" content="672" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="404 page - GoodCrypto" />
<meta name="twitter:site" content="@GoodCryptoApp" />
<meta name="twitter:image" content="https://goodcrypto.app/wp-content/uploads/2023/05/photo_2023-05-05_12-14-53.jpg" />
<meta name="twitter:creator" content="@GoodCryptoApp" />
<script type='application/ld+json' class='yoast-schema-graph yoast-schema-graph--main'>{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://goodcrypto.app/#organization","name":"Good Crypto","url":"https://goodcrypto.app/","sameAs":["https://www.facebook.com/GoodCryptoApp","https://www.linkedin.com/company/goodcrypto/","https://www.youtube.com/channel/UCage4jOHPNVEmMpTH60TDMA","https://twitter.com/GoodCryptoApp"],"logo":{"@type":"ImageObject","@id":"https://goodcrypto.app/#logo","url":"https://goodcrypto.app/wp-content/uploads/2022/01/logo1-1.svg","caption":"Good Crypto"},"image":{"@id":"https://goodcrypto.app/#logo"}},{"@type":"WebSite","@id":"https://goodcrypto.app/#website","url":"https://goodcrypto.app/","name":"GoodCrypto","description":"GoodCrypto","publisher":{"@id":"https://goodcrypto.app/#organization"},"potentialAction":{"@type":"SearchAction","target":"https://goodcrypto.app/?s={search_term_string}","query-input":"required name=search_term_string"}},{"@type":"WebPage","@id":"https://goodcrypto.app/404-page/#webpage","url":"https://goodcrypto.app/404-page/","inLanguage":"en-US","name":"404 page - GoodCrypto","isPartOf":{"@id":"https://goodcrypto.app/#website"},"datePublished":"2020-04-06T15:01:01+00:00","dateModified":"2020-04-06T15:01:01+00:00"}]}</script>

<link rel='stylesheet' id='wp-block-library-css'  href='https://goodcrypto.app/wp-includes/css/dist/block-library/style.min.css?ver=5.5.5' media='all' />
<link rel='stylesheet' id='wpml-blocks-css'  href='https://goodcrypto.app/wp-content/plugins/sitepress-multilingual-cms/dist/css/blocks/styles.css?ver=4.6.3' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://goodcrypto.app/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='wpml-legacy-dropdown-0-css'  href='//goodcrypto.app/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-dropdown/style.min.css?ver=1' media='all' />
<link rel='stylesheet' id='wpml-legacy-horizontal-list-0-css'  href='//goodcrypto.app/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-list-horizontal/style.min.css?ver=1' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://goodcrypto.app/wp-content/themes/main-template/plugins/bootstrap/css/bootstrap.min.css?ver=5.5.5' media='all' />
<link rel='stylesheet' id='rangeslider-css'  href='https://goodcrypto.app/wp-content/themes/main-template/plugins/rangeslider/rangeslider.css?ver=5.5.5' media='all' />
<link rel='stylesheet' id='style-css'  href='https://goodcrypto.app/wp-content/themes/main-template/css/template.css?ver=1735824877' media='all' />
<meta name="generator" content="WPML ver:4.6.3 stt:60,1,4,3,27,42,46,2,54,55;" />
<script data-phast-no-defer>console.log("%cOptimized with %cPhastPress%c %s\nhttps:\/\/wordpress.org\/plugins\/phastpress\/","font-family:helvetica,sans-serif","font-family:helvetica,sans-serif;font-weight:bold","font-family:helvetica,sans-serif","1.114")</script>
<link rel="shortcut icon" sizes="48x48" type="image/ico" href="https://goodcrypto.app/wp-content/themes/main-template/images/favicon/favicon.ico">
<link rel="shortcut icon" sizes="48x48" type="image/png" href="https://goodcrypto.app/wp-content/themes/main-template/images/favicon/favicon_48.png">
<link rel="shortcut icon" sizes="96x96" type="image/png" href="https://goodcrypto.app/wp-content/themes/main-template/images/favicon/favicon_96.png">
</head>
<body class="page-template page-template-pages page-template-404-error page-template-pages404-error-php page page-id-987 transition-off">

<noscript><iframe data-phast-src="https://www.googletagmanager.com/ns.html?id=GTM-PRN6G3K" src="about:blank" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>


<div class="manage d-flex d-xl-none">
<div class="logo">
<a id="header-logo" href="https://goodcrypto.app">
<img loading="eager" id="header-logo" src="https://goodcrypto.app/wp-content/uploads/2023/10/mobile-logo.svg" width="74" height="36" alt="logo">
</a>
</div>
<div class="m-right d-flex align-items-center">
<div class="languages-widget-header">
<div
	 class="wpml-ls-sidebars-languages-widget-header wpml-ls wpml-ls-legacy-dropdown js-wpml-ls-legacy-dropdown">
<ul>
<li tabindex="0" class="wpml-ls-slot-languages-widget-header wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-first-item wpml-ls-last-item wpml-ls-item-legacy-dropdown">
<a href="#" class="js-wpml-ls-item-toggle wpml-ls-item-toggle">
<span class="wpml-ls-native">EN</span></a>
<ul class="wpml-ls-sub-menu">
</ul>
</li>
</ul>
</div>
</div> <div class="humb ml-4">
<div></div>
<div></div>
</div>
</div>
</div>
<div class="left-menu">
<div class="close-menu">
<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
<path d="M13 13L1 1M13 1L1 13" stroke="#4D4D4D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
</svg>
</div>
<div class="for-menu">
<div class="menu-wrapper"><ul id="mob-main-menu" class="menu"><li id="menu-item-26860" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26860"><a href="https://goodcrypto.app/prices/">Plans</a></li>
<li id="menu-item-28503" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-28503"><a href="https://goodcrypto.app/about-us/">About us</a></li>
<li id="menu-item-24377" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24377"><a href="https://goodcrypto.app/affiliate-program/">Affiliate program</a></li>
<li id="menu-item-27374" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-27374"><a href="#">More</a>
<ul class="sub-menu">
<li id="menu-item-1219" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1219"><a href="https://goodcrypto.app/security/">Security</a></li>
<li id="menu-item-2468" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2468"><a href="https://goodcrypto.app/blog/">Blog</a></li>
<li id="menu-item-1814" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1814"><a href="https://goodcrypto.app/faq/">FAQ</a></li>
<li id="menu-item-27450" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-27450"><a href="#">Tools</a>
<ul class="sub-menu">
<li id="menu-item-27451" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27451"><a href="https://goodcrypto.app/liquidity-checker/">Liquidity Checker</a></li>
<li id="menu-item-27452" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27452"><a href="https://goodcrypto.app/crypto-screener-check-live-cryptocurrency-prices/">Crypto Screener</a></li>
</ul>
</li>
</ul>
</li>
</ul></div>
<div class="order mt-5">
<a id="button_x_header" class="x-btn" href="https://goodcrypto.app/x/" target="" data-text="new 🔥">
<?xml version="1.0" encoding="utf-8"?>
<svg width="127" height="20" viewBox="0 0 127 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_5128_11847)">
<path class="change-color" d="M11.4272 4.57555H10.0469L9.33366 5.70158C8.34758 4.79525 7.08564 4.15625 5.70984 4.15625C2.55649 4.15625 0 6.66007 0 9.74822C0 12.8364 2.55799 15.3402 5.70984 15.3402C7.01392 15.3402 8.21768 14.8211 9.17969 14.0311V15.1105C8.84765 16.6889 7.4242 17.8766 5.71285 17.8766C5.18157 17.8785 4.65659 17.7616 4.17633 17.5344C3.69607 17.3072 3.27269 16.9754 2.93717 16.5635H0.440378C1.30207 18.5813 3.33793 19.9997 5.71285 19.9997C8.82257 19.9997 11.354 17.8731 11.4222 14.5462H11.4272V4.57555ZM5.70934 13.2166C3.75323 13.2166 2.16777 11.6617 2.16777 9.74822C2.16777 7.83474 3.75323 6.27988 5.70934 6.27988C7.42119 6.27988 8.84915 7.46909 9.17918 9.05053V10.4464C8.84965 12.0273 7.42169 13.2191 5.70984 13.2191L5.70934 13.2166Z" fill="#010B13"/>
<path class="change-color" d="M48.8075 0L48.8131 5.58546C47.839 4.71423 46.5881 4.17454 45.2238 4.17454C42.1141 4.17454 39.5938 6.63724 39.5938 9.7289C39.5938 12.8206 42.1146 15.3259 45.2238 15.3259C46.6092 15.3259 47.8771 14.6578 48.8582 13.7209L49.6888 15.0249H51.0932V0.010531L48.8075 0ZM45.27 13.2148C43.3415 13.2148 41.8739 11.6599 41.8739 9.74395C41.8739 7.82796 43.2682 6.41805 45.1968 6.41805C46.7797 6.41805 48.316 7.31185 48.8161 8.74232V10.7315C48.331 12.166 46.8479 13.2148 45.27 13.2148Z" fill="#010B13"/>
<path class="change-color" d="M72.1473 4.57617H69.5573L68.501 6.22884V4.57617H67.076H66.2344V15.0243L68.501 15.0349V6.41943L72.1473 6.41893V4.57617Z" fill="#010B13"/>
<path class="change-color" d="M106.181 6.41813V4.58841H103.59L102.575 6.17739V0.015625H101.171L100.303 1.37989L100.289 11.8932V12.28H100.295C100.35 13.0341 100.689 13.7392 101.243 14.254C101.797 14.7688 102.525 15.0552 103.281 15.0556H106.163V13.2319H103.518C103.394 13.232 103.271 13.2076 103.156 13.1601C103.042 13.1127 102.938 13.0431 102.85 12.9553C102.762 12.8675 102.692 12.7634 102.645 12.6487C102.598 12.534 102.573 12.4111 102.573 12.287V6.41863L106.181 6.41813Z" fill="#010B13"/>
<path class="change-color" d="M61.8184 11.3105C61.52 11.8832 61.0699 12.3629 60.5173 12.6971C59.9647 13.0313 59.3308 13.2071 58.6851 13.2054C56.7405 13.2054 55.1641 11.6505 55.1641 9.72904C55.1641 7.80753 56.7405 6.25268 58.6851 6.25268C59.3361 6.25098 59.975 6.42978 60.5306 6.76925C61.0862 7.10872 61.5368 7.59556 61.8324 8.17568H64.1396C63.457 5.83587 61.2736 4.12402 58.6846 4.12402C55.5493 4.12402 53.0078 6.63186 53.0078 9.72904C53.0078 12.8262 55.5493 15.3335 58.6846 15.3335C61.2636 15.3335 63.4399 13.6357 64.1316 11.3105H61.8184Z" fill="#010B13"/>
<path class="change-color" d="M82.3446 4.59668L79.1902 13.2031L76.2465 4.59668H73.9453L77.6178 15.3337H78.4088L76.6984 19.9998H78.9996L84.6458 4.59668H82.3446Z" fill="#010B13"/>
<path class="change-color" d="M92.6394 4.16895C91.235 4.16895 89.9259 4.83102 88.9399 5.79001L88.1719 4.59729H86.75V19.9909L89.0331 20.0019L89.0086 13.8647C89.9851 14.745 91.242 15.3353 92.6143 15.3353C95.7241 15.3353 98.2414 12.8305 98.2414 9.74035C98.2414 6.65019 95.7471 4.16895 92.6394 4.16895ZM92.6143 13.2152C91.0033 13.2152 89.4595 12.1258 88.9955 10.6492L88.9885 8.84907C89.4399 7.36694 90.9817 6.41847 92.5998 6.41847C94.5273 6.41847 95.9658 7.82737 95.9658 9.74437C95.9658 11.6614 94.5419 13.2152 92.6143 13.2152Z" fill="#010B13"/>
<path class="change-color" d="M18.9958 4.14355C15.8671 4.14355 13.3281 6.64788 13.3281 9.73704C13.3281 12.8262 15.8646 15.3305 18.9958 15.3305C22.1271 15.3305 24.661 12.8262 24.661 9.73704C24.661 6.64788 22.1246 4.14355 18.9958 4.14355ZM18.9958 13.2064C17.0553 13.2064 15.4824 11.6515 15.4824 9.73704C15.4824 7.82255 17.0553 6.26769 18.9958 6.26769C20.9364 6.26769 22.5098 7.82255 22.5098 9.73704C22.5098 11.6515 20.9349 13.2064 18.9958 13.2064Z" fill="#010B13"/>
<path class="change-color" d="M32.0637 4.14355C28.9349 4.14355 26.3984 6.64788 26.3984 9.73704C26.3984 12.8262 28.9349 15.3305 32.0637 15.3305C35.1924 15.3305 37.7314 12.8262 37.7314 9.73704C37.7314 6.64788 35.1924 4.14355 32.0637 4.14355ZM32.0637 13.2064C30.1231 13.2064 28.5527 11.6515 28.5527 9.73704C28.5527 7.82255 30.1256 6.26769 32.0637 6.26769C34.0017 6.26769 35.5776 7.82255 35.5776 9.73704C35.5776 11.6515 34.0042 13.2064 32.0637 13.2064Z" fill="#010B13"/>
<path d="M119.752 11.2508L121.251 9.75115L126.828 4.17321L123.834 4.16418L119.75 8.24945L119.741 8.24093L118.24 9.74161L118.248 9.74964L115.936 12.0619L115.679 12.3187C115.029 12.8997 114.188 13.2202 113.317 13.2185C111.378 13.2185 109.806 11.6676 109.806 9.75115C109.806 7.83466 111.378 6.28431 113.317 6.28431C114.247 6.28193 115.139 6.64721 115.801 7.30049L116.927 8.4265L118.427 6.92582L117.613 6.11127C117.441 5.91222 117.255 5.72598 117.056 5.55403L117.026 5.52444C115.993 4.64134 114.678 4.15737 113.318 4.16017C110.192 4.16017 107.656 6.664 107.656 9.75015C107.656 12.8363 110.192 15.3401 113.318 15.3401C114.667 15.3432 115.972 14.8667 117.002 13.9959L117.022 13.9759C117.243 13.7873 117.449 13.5815 117.637 13.3604L119.75 11.2473L119.752 11.2508Z" fill="url(#paint0_linear_5128_11847)"/>
<path d="M122.569 11.0664L121.07 12.5661L123.864 15.3553H126.866L122.569 11.0664Z" fill="url(#paint1_linear_5128_11847)"/>
<path d="M126.826 4.17454L123.832 4.16602L117.789 10.2084L119.27 11.7307L126.826 4.17454Z" fill="url(#paint2_linear_5128_11847)"/>
</g>
<defs>
<linearGradient id="paint0_linear_5128_11847" x1="107.655" y1="9.75315" x2="126.828" y2="9.75315" gradientUnits="userSpaceOnUse">
<stop class="change-color" offset="0.151042" stop-color="#010B13"/>
<stop offset="0.48" stop-color="#01EF67"/>
</linearGradient>
<linearGradient id="paint1_linear_5128_11847" x1="122.051" y1="24.9177" x2="125.642" y2="4.39455" gradientUnits="userSpaceOnUse">
<stop offset="0.54" stop-color="#01EF67"/>
<stop offset="0.66" stop-color="#01EF67"/>
<stop offset="0.67" stop-color="#092CFB"/>
</linearGradient>
<linearGradient id="paint2_linear_5128_11847" x1="123.011" y1="11.3931" x2="121.832" y2="4.35109" gradientUnits="userSpaceOnUse">
<stop offset="0.23" stop-color="#01EF67" stop-opacity="0"/>
<stop offset="1" stop-color="#092CFB"/>
</linearGradient>
<clipPath id="clip0_5128_11847">
<rect width="126.864" height="20" fill="white"/>
</clipPath>
</defs>
</svg>
</a>
</div>
<div class="bottoms mt-auto">
<hr class="ln-1 d-none">
<div class="buttons">
<div class="order sgn-btn">
<a rel="nofollow" class="sign-in-btn bord" id="header_sign_in" href="https://click.goodcrypto.app/b9EC/06s2de8x" target="_blank">Sign іn </a>
</div>
<div class="order fr-btn">
<a rel="nofollow" class="gradient-btn w-100" id="header_try_free" href="https://click.goodcrypto.app/b9EC/8k29u7to" target="_blank">Try for FREE </a>
</div>
</div>
<hr class="ln-2">
<div class="for-social">
<div class="social justify-content-xl-end">
<a id="facebook1" rel="nofollow noopener" href="https://www.facebook.com/GoodCryptoApp">
<i id="facebook1" class="fab fa-facebook-f"></i>
</a>
<a id="twitter1" rel="nofollow noopener" href="https://twitter.com/GoodCryptoApp">
<i id="twitter1" class="fab fa-twitter"></i>
</a>
<a id="linkedin1" rel="nofollow noopener" href="https://www.linkedin.com/company/goodcrypto/">
<i id="linkedin1" class="fab fa-linkedin-in"></i>
</a>
<a id="telegram1" rel="nofollow noopener" href="https://t.me/goodcrypto">
<i id="telegram1" class="fab fa-telegram-plane"></i>
</a>
<a id="medium1" rel="nofollow noopener" href="https://medium.com/cryptto-io">
<i id="medium1" class="fab fa-medium-m"></i>
</a>
<a id="reddit1" rel="nofollow noopener" href="https://www.reddit.com/r/GoodCrypto">
<i id="reddit1" class="fab fa-reddit-alien"></i>
</a>
<a id="youtube1" rel="nofollow noopener" href="https://www.youtube.com/channel/UCage4jOHPNVEmMpTH60TDMA">
<i id="youtube1" class="fab fa-youtube"></i>
</a>
</div>
</div>
</div>
</div>
</div>
<div class="wrapper">


<div class="banner-line dex-banner-line fixed-banner">
<a id="top-dex-banner" target="_blank" href="https://click.goodcrypto.app/b9EC/1nqhaifq" class="dex-banner">
<div class="container big d-flex align-items-center">
<div class="tit">
<span>First non-custodial DEX trading bot.</span> Join DEX trading revolution with goodcryptoX! </div>
<div class="order">
<button id="dex_btn" class="white-btn" type="button">
LAUNCH BOT </button>
</div>
</div>
</a>
<div class="close-wrapper">
<div class="container big">
<div id="close" class="for-close">&times;</div>
</div>
</div>
</div>
<header class="header d-none d-xl-block">

<div class="container big">
<div class="row align-items-center">
<div class="col-xl-auto">
<div class="logo">
<a id="header-logo" href="https://goodcrypto.app">
<img loading="eager" id="header-logo" src="https://goodcrypto.app/wp-content/uploads/2020/03/logo1.svg" width="273" height="30" alt="logo">
</a>
</div>
</div>
<div class="col-xl d-flex align-items-center justify-content-center">
<div class="menu-wrapper"><ul id="header-main-menu" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26860"><a href="https://goodcrypto.app/prices/">Plans</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-28503"><a href="https://goodcrypto.app/about-us/">About us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-24377"><a href="https://goodcrypto.app/affiliate-program/">Affiliate program</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-27374"><a href="#">More</a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1219"><a href="https://goodcrypto.app/security/">Security</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2468"><a href="https://goodcrypto.app/blog/">Blog</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1814"><a href="https://goodcrypto.app/faq/">FAQ</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-27450"><a href="#">Tools</a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27451"><a href="https://goodcrypto.app/liquidity-checker/">Liquidity Checker</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27452"><a href="https://goodcrypto.app/crypto-screener-check-live-cryptocurrency-prices/">Crypto Screener</a></li>
</ul>
</li>
</ul>
</li>
</ul></div> <div class="order ml-xl-5">
<a id="header_x_button" class="x-btn" href="https://goodcrypto.app/x/" target="" data-text="new 🔥">
<?xml version="1.0" encoding="utf-8"?>
<svg width="127" height="20" viewBox="0 0 127 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_5128_11847)">
<path class="change-color" d="M11.4272 4.57555H10.0469L9.33366 5.70158C8.34758 4.79525 7.08564 4.15625 5.70984 4.15625C2.55649 4.15625 0 6.66007 0 9.74822C0 12.8364 2.55799 15.3402 5.70984 15.3402C7.01392 15.3402 8.21768 14.8211 9.17969 14.0311V15.1105C8.84765 16.6889 7.4242 17.8766 5.71285 17.8766C5.18157 17.8785 4.65659 17.7616 4.17633 17.5344C3.69607 17.3072 3.27269 16.9754 2.93717 16.5635H0.440378C1.30207 18.5813 3.33793 19.9997 5.71285 19.9997C8.82257 19.9997 11.354 17.8731 11.4222 14.5462H11.4272V4.57555ZM5.70934 13.2166C3.75323 13.2166 2.16777 11.6617 2.16777 9.74822C2.16777 7.83474 3.75323 6.27988 5.70934 6.27988C7.42119 6.27988 8.84915 7.46909 9.17918 9.05053V10.4464C8.84965 12.0273 7.42169 13.2191 5.70984 13.2191L5.70934 13.2166Z" fill="#010B13"/>
<path class="change-color" d="M48.8075 0L48.8131 5.58546C47.839 4.71423 46.5881 4.17454 45.2238 4.17454C42.1141 4.17454 39.5938 6.63724 39.5938 9.7289C39.5938 12.8206 42.1146 15.3259 45.2238 15.3259C46.6092 15.3259 47.8771 14.6578 48.8582 13.7209L49.6888 15.0249H51.0932V0.010531L48.8075 0ZM45.27 13.2148C43.3415 13.2148 41.8739 11.6599 41.8739 9.74395C41.8739 7.82796 43.2682 6.41805 45.1968 6.41805C46.7797 6.41805 48.316 7.31185 48.8161 8.74232V10.7315C48.331 12.166 46.8479 13.2148 45.27 13.2148Z" fill="#010B13"/>
<path class="change-color" d="M72.1473 4.57617H69.5573L68.501 6.22884V4.57617H67.076H66.2344V15.0243L68.501 15.0349V6.41943L72.1473 6.41893V4.57617Z" fill="#010B13"/>
<path class="change-color" d="M106.181 6.41813V4.58841H103.59L102.575 6.17739V0.015625H101.171L100.303 1.37989L100.289 11.8932V12.28H100.295C100.35 13.0341 100.689 13.7392 101.243 14.254C101.797 14.7688 102.525 15.0552 103.281 15.0556H106.163V13.2319H103.518C103.394 13.232 103.271 13.2076 103.156 13.1601C103.042 13.1127 102.938 13.0431 102.85 12.9553C102.762 12.8675 102.692 12.7634 102.645 12.6487C102.598 12.534 102.573 12.4111 102.573 12.287V6.41863L106.181 6.41813Z" fill="#010B13"/>
<path class="change-color" d="M61.8184 11.3105C61.52 11.8832 61.0699 12.3629 60.5173 12.6971C59.9647 13.0313 59.3308 13.2071 58.6851 13.2054C56.7405 13.2054 55.1641 11.6505 55.1641 9.72904C55.1641 7.80753 56.7405 6.25268 58.6851 6.25268C59.3361 6.25098 59.975 6.42978 60.5306 6.76925C61.0862 7.10872 61.5368 7.59556 61.8324 8.17568H64.1396C63.457 5.83587 61.2736 4.12402 58.6846 4.12402C55.5493 4.12402 53.0078 6.63186 53.0078 9.72904C53.0078 12.8262 55.5493 15.3335 58.6846 15.3335C61.2636 15.3335 63.4399 13.6357 64.1316 11.3105H61.8184Z" fill="#010B13"/>
<path class="change-color" d="M82.3446 4.59668L79.1902 13.2031L76.2465 4.59668H73.9453L77.6178 15.3337H78.4088L76.6984 19.9998H78.9996L84.6458 4.59668H82.3446Z" fill="#010B13"/>
<path class="change-color" d="M92.6394 4.16895C91.235 4.16895 89.9259 4.83102 88.9399 5.79001L88.1719 4.59729H86.75V19.9909L89.0331 20.0019L89.0086 13.8647C89.9851 14.745 91.242 15.3353 92.6143 15.3353C95.7241 15.3353 98.2414 12.8305 98.2414 9.74035C98.2414 6.65019 95.7471 4.16895 92.6394 4.16895ZM92.6143 13.2152C91.0033 13.2152 89.4595 12.1258 88.9955 10.6492L88.9885 8.84907C89.4399 7.36694 90.9817 6.41847 92.5998 6.41847C94.5273 6.41847 95.9658 7.82737 95.9658 9.74437C95.9658 11.6614 94.5419 13.2152 92.6143 13.2152Z" fill="#010B13"/>
<path class="change-color" d="M18.9958 4.14355C15.8671 4.14355 13.3281 6.64788 13.3281 9.73704C13.3281 12.8262 15.8646 15.3305 18.9958 15.3305C22.1271 15.3305 24.661 12.8262 24.661 9.73704C24.661 6.64788 22.1246 4.14355 18.9958 4.14355ZM18.9958 13.2064C17.0553 13.2064 15.4824 11.6515 15.4824 9.73704C15.4824 7.82255 17.0553 6.26769 18.9958 6.26769C20.9364 6.26769 22.5098 7.82255 22.5098 9.73704C22.5098 11.6515 20.9349 13.2064 18.9958 13.2064Z" fill="#010B13"/>
<path class="change-color" d="M32.0637 4.14355C28.9349 4.14355 26.3984 6.64788 26.3984 9.73704C26.3984 12.8262 28.9349 15.3305 32.0637 15.3305C35.1924 15.3305 37.7314 12.8262 37.7314 9.73704C37.7314 6.64788 35.1924 4.14355 32.0637 4.14355ZM32.0637 13.2064C30.1231 13.2064 28.5527 11.6515 28.5527 9.73704C28.5527 7.82255 30.1256 6.26769 32.0637 6.26769C34.0017 6.26769 35.5776 7.82255 35.5776 9.73704C35.5776 11.6515 34.0042 13.2064 32.0637 13.2064Z" fill="#010B13"/>
<path d="M119.752 11.2508L121.251 9.75115L126.828 4.17321L123.834 4.16418L119.75 8.24945L119.741 8.24093L118.24 9.74161L118.248 9.74964L115.936 12.0619L115.679 12.3187C115.029 12.8997 114.188 13.2202 113.317 13.2185C111.378 13.2185 109.806 11.6676 109.806 9.75115C109.806 7.83466 111.378 6.28431 113.317 6.28431C114.247 6.28193 115.139 6.64721 115.801 7.30049L116.927 8.4265L118.427 6.92582L117.613 6.11127C117.441 5.91222 117.255 5.72598 117.056 5.55403L117.026 5.52444C115.993 4.64134 114.678 4.15737 113.318 4.16017C110.192 4.16017 107.656 6.664 107.656 9.75015C107.656 12.8363 110.192 15.3401 113.318 15.3401C114.667 15.3432 115.972 14.8667 117.002 13.9959L117.022 13.9759C117.243 13.7873 117.449 13.5815 117.637 13.3604L119.75 11.2473L119.752 11.2508Z" fill="url(#paint0_linear_5128_11847)"/>
<path d="M122.569 11.0664L121.07 12.5661L123.864 15.3553H126.866L122.569 11.0664Z" fill="url(#paint1_linear_5128_11847)"/>
<path d="M126.826 4.17454L123.832 4.16602L117.789 10.2084L119.27 11.7307L126.826 4.17454Z" fill="url(#paint2_linear_5128_11847)"/>
</g>
<defs>
<linearGradient id="paint0_linear_5128_11847" x1="107.655" y1="9.75315" x2="126.828" y2="9.75315" gradientUnits="userSpaceOnUse">
<stop class="change-color" offset="0.151042" stop-color="#010B13"/>
<stop offset="0.48" stop-color="#01EF67"/>
</linearGradient>
<linearGradient id="paint1_linear_5128_11847" x1="122.051" y1="24.9177" x2="125.642" y2="4.39455" gradientUnits="userSpaceOnUse">
<stop offset="0.54" stop-color="#01EF67"/>
<stop offset="0.66" stop-color="#01EF67"/>
<stop offset="0.67" stop-color="#092CFB"/>
</linearGradient>
<linearGradient id="paint2_linear_5128_11847" x1="123.011" y1="11.3931" x2="121.832" y2="4.35109" gradientUnits="userSpaceOnUse">
<stop offset="0.23" stop-color="#01EF67" stop-opacity="0"/>
<stop offset="1" stop-color="#092CFB"/>
</linearGradient>
<clipPath id="clip0_5128_11847">
<rect width="126.864" height="20" fill="white"/>
</clipPath>
</defs>
</svg>
</a>
</div>
</div>
<div class="col-xl-auto">
<div class="buttons">
<div class="order">
<a id="header_sign_in" rel="nofollow" class="sign-in-btn" href="https://click.goodcrypto.app/b9EC/06s2de8x" target="_blank">Sign іn </a>
</div>
<div class="order">
<a id="header_try_free" rel="nofollow" class="gradient-btn" href="https://click.goodcrypto.app/b9EC/8k29u7to" target="_blank">Try for FREE </a>
</div>
</div>
</div>
<div class="col-xl-auto">
<div class="languages-widget-header">
<div
	 class="wpml-ls-sidebars-languages-widget-header wpml-ls wpml-ls-legacy-dropdown js-wpml-ls-legacy-dropdown">
<ul>
<li tabindex="0" class="wpml-ls-slot-languages-widget-header wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-first-item wpml-ls-last-item wpml-ls-item-legacy-dropdown">
<a href="#" class="js-wpml-ls-item-toggle wpml-ls-item-toggle">
<span class="wpml-ls-native">EN</span></a>
<ul class="wpml-ls-sub-menu">
</ul>
</li>
</ul>
</div>
</div> </div>
</div>
</div>
</header>
<section class="page-404">
<div class="container">
<div class="row align-items-center">
<div class="col-12 col-lg-6">
<div class="p-left">
<div class="title lined">404</div>
<div class="min-title gray">
Oops! The page you’re looking for got lost or <br class="d-none d-xl-inline"> doesn’t exist
</div>
<div class="order">
<a href="https://goodcrypto.app">Go Home</a>
</div>
</div>
</div>
<div class="col-12 col-lg-6">
<div class="pic lines">
<img loading="lazy" src="https://goodcrypto.app/wp-content/themes/main-template/images/404_visual.svg" width="670" height="602" alt="404">
</div>
</div>
</div>
</div>
</section>
<footer class="footer">
<div class="f-top">
<div class="container big">
<div class="menu-wrapper footer-links-menu"><ul id="footer-links-menu" class="menu"><li id="menu-item-7070" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7070"><a href="https://goodcrypto.app/faq/api-keys-faq/">API Keys</a>
<ul class="sub-menu">
<li id="menu-item-7076" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7076"><a href="https://goodcrypto.app/binance-api-key/">Binance API key</a></li>
<li id="menu-item-7071" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7071"><a href="https://goodcrypto.app/how-to-configure-bitfinex-api-keys-and-add-them-to-good-crypto/">Bitfinex API key</a></li>
<li id="menu-item-142736" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-142736"><a href="https://goodcrypto.app/how-to-configure-bitget-api-key-and-add-it-to-good-crypto/">Bitget API key</a></li>
<li id="menu-item-10806" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10806"><a href="https://goodcrypto.app/how-to-configure-bitmart-api-key-and-add-it-to-goodcrypto-app/">BitMart API key</a></li>
<li id="menu-item-8534" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-8534"><a href="https://goodcrypto.app/how-to-configure-bitmex-api-key-and-add-it-to-good-crypto-app/">BitMEX API key</a></li>
<li id="menu-item-8535" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-8535"><a href="https://goodcrypto.app/how-to-configure-bybit-api-keys-and-add-them-to-good-crypto/">Bybit API key</a></li>
<li id="menu-item-135107" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-135107"><a href="https://goodcrypto.app/how-to-configure-coinbase-api-key-and-add-it-to-good-crypto/">Coinbase API key</a></li>
<li id="menu-item-135108" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-135108"><a href="https://goodcrypto.app/how-to-connect-your-dydx-v3-account-to-goodcrypto-app/">dYdX v3 API key</a></li>
<li id="menu-item-28455" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-28455"><a href="https://goodcrypto.app/how-to-configure-gate-io-api-key-and-add-it-to-good-crypto/">Gate.io API key</a></li>
<li id="menu-item-7075" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7075"><a href="https://goodcrypto.app/kraken-api-key/">Kraken API key</a></li>
<li id="menu-item-7072" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7072"><a href="https://goodcrypto.app/how-to-configure-kucoin-api-keys-and-add-them/">KuCoin API key</a></li>
<li id="menu-item-7436" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7436"><a href="https://goodcrypto.app/how-to-configure-kucoin-futures-api-key-and-add/">KuCoin‌ ‌Futures‌ ‌API‌ ‌key‌</a></li>
<li id="menu-item-11940" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-11940"><a href="https://goodcrypto.app/how-to-configure-okx-api-key-and-okx-futures-api-key-and-add-it-to-good-crypto/">OKX API key</a></li>
<li id="menu-item-11939" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-11939"><a href="https://goodcrypto.app/how-to-configure-phemex-api-key-and-add-it-to-good-crypto/">Phemex API key</a></li>
<li id="menu-item-28456" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-28456"><a href="https://goodcrypto.app/how-to-configure-whitebit-api-key-and-add-it-to-good-crypto/">WhiteBIT API key</a></li>
</ul>
</li>
<li id="menu-item-7047" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7047"><a href="https://goodcrypto.app/blog/trading-strategies/">Trading Strategies</a>
<ul class="sub-menu">
<li id="menu-item-62083" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-62083"><a href="https://goodcrypto.app/tradingview-bot/">TradingView Bot</a></li>
<li id="menu-item-28189" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-28189"><a href="https://goodcrypto.app/infinity-trailing-bot-ride-the-trend-until-its-end-and-gain/">Infinity Trailing Bot</a></li>
<li id="menu-item-7572" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7572"><a href="https://goodcrypto.app/moving-averages-sma-ema-wma-a-complete-guide-for-traders-explained-by-good-crypto/">Moving Averages</a></li>
<li id="menu-item-7064" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7064"><a href="https://goodcrypto.app/trailing-stop-order-a-definitive-guide/">Trailing Stop</a></li>
<li id="menu-item-7062" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7062"><a href="https://goodcrypto.app/how-to-trade-with-trend-lines-a-full-guide-exemplified-by-good-crypto/">Trend Lines</a></li>
<li id="menu-item-7063" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7063"><a href="https://goodcrypto.app/bollinger-bands-a-complete-guide-for-traders-exemplified-by-good-crypto-charts/">Bollinger Bands</a></li>
<li id="menu-item-8532" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-8532"><a href="https://goodcrypto.app/chart-patterns-for-crypto-trading-trading-patterns-explained/">Chart Patterns</a></li>
<li id="menu-item-8531" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-8531"><a href="https://goodcrypto.app/relative-strength-index-rsi-indicator-for-crypto-trading-an-ultimate-guide-by-good-crypto/">RSI Indicator</a></li>
<li id="menu-item-8530" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-8530"><a href="https://goodcrypto.app/the-macd-indicator-and-the-macd-trading-strategies-a-detailed-guide-by-good-crypto/">MACD Indicator</a></li>
<li id="menu-item-10240" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10240"><a href="https://goodcrypto.app/supertrend-indicator-how-to-set-up-use-and-create-profitable-crypto-trading-strategy/">Supertrend Indicator</a></li>
<li id="menu-item-10241" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10241"><a href="https://goodcrypto.app/advanced-moving-averages-smma-ama-lwma-dema-tema-a-complete-guide-for-crypto-traders/">Moving Averages 2.0</a></li>
<li id="menu-item-10243" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10243"><a href="https://goodcrypto.app/ichimoku-cloud-definition-and-uses-a-complete-guide-for-crypto-traders-exemplified-by-good-crypto/">Ichimoku Cloud</a></li>
<li id="menu-item-10244" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10244"><a href="https://goodcrypto.app/how-to-trade-with-fibonacci-retracement-in-crypto-a-complete-guide-by-good-crypto/">Fibonacci Retracement</a></li>
</ul>
</li>
<li id="menu-item-7050" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7050"><a href="https://goodcrypto.app/blog/education/">Learn</a>
<ul class="sub-menu">
<li id="menu-item-7065" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7065"><a href="https://goodcrypto.app/kraken-vs-coinbase-pro-a-full-guide-for-2022/">Kraken vs Coinbase Pro</a></li>
<li id="menu-item-7068" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7068"><a href="https://goodcrypto.app/what-is-defi-in-crypto/">What is DeFi in Crypto</a></li>
<li id="menu-item-7573" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-7573"><a href="https://goodcrypto.app/what-is-liquidity-and-how-to-find-a-liquid-exchange/">What is Liquidity</a></li>
<li id="menu-item-8533" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-8533"><a href="https://goodcrypto.app/cryptocurrency-portfolio-and-risk-management-a-full-overview-for-traders-by-good-crypto/">Portfolio Management</a></li>
<li id="menu-item-10239" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10239"><a href="https://goodcrypto.app/crypto-trading-bots-what-bots-and-strategies-to-use-to-make-your-trading-lucrative/">Crypto Trading Bots</a></li>
<li id="menu-item-10692" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10692"><a href="https://goodcrypto.app/gemini-vs-coinbase-a-full-overview-for-2022/">Gemini vs Coinbase</a></li>
<li id="menu-item-10805" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-10805"><a href="https://goodcrypto.app/binance-vs-bitfinex-full-review-and-comparison-by-good-crypto-2022/">Binance vs Bitfinex</a></li>
<li id="menu-item-11801" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-11801"><a href="https://goodcrypto.app/binance-vs-coinbase-whats-a-better-alternative/">Binance vs Coinbase</a></li>
</ul>
</li>
<li id="menu-item-10696" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10696"><a>Trade Bots</a>
<ul class="sub-menu">
<li id="menu-item-137926" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-137926"><a href="https://goodcrypto.app/arbitrum-trading-bot/">Arbitrum Bot</a></li>
<li id="menu-item-140954" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-140954"><a href="https://goodcrypto.app/ai-trading-bot/">AI Bot</a></li>
<li id="menu-item-11800" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11800"><a href="https://goodcrypto.app/binance-trading-bot/">Binance Bot</a></li>
<li id="menu-item-14848" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-14848"><a href="https://goodcrypto.app/binanceus-trading-bot/">Binance.US Bot</a></li>
<li id="menu-item-137928" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-137928"><a href="https://goodcrypto.app/binance-smart-chain-bsc-bot/">Binance Smart Chain Bot</a></li>
<li id="menu-item-137927" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-137927"><a href="https://goodcrypto.app/base-trading-bot/">Base Bot</a></li>
<li id="menu-item-15026" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15026"><a href="https://goodcrypto.app/bitfinex-trading-bot/">Bitfinex Bot</a></li>
<li id="menu-item-15897" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15897"><a href="https://goodcrypto.app/bitmex-trading-bot/">BitMEX Bot</a></li>
<li id="menu-item-16943" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16943"><a href="https://goodcrypto.app/bittrex-trading-bot/">Bittrex Bot</a></li>
<li id="menu-item-17732" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17732"><a href="https://goodcrypto.app/bitstamp-trading-bot/">Bitstamp Bot</a></li>
<li id="menu-item-15025" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15025"><a href="https://goodcrypto.app/bybit-trading-bot/">Bybit Bot</a></li>
<li id="menu-item-14626" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-14626"><a href="https://goodcrypto.app/coinbase-trading-bot/">Coinbase Bot</a></li>
<li id="menu-item-17187" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17187"><a href="https://goodcrypto.app/crypto-com-trading-bot/">Crypto.com Bot</a></li>
<li id="menu-item-135109" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-135109"><a href="https://goodcrypto.app/dydx-trading-bot/">dYdX Bot</a></li>
<li id="menu-item-16602" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16602"><a href="https://goodcrypto.app/gemini-trading-bot/">Gemini Bot</a></li>
<li id="menu-item-16603" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16603"><a href="https://goodcrypto.app/gate-io-trading-bot/">Gate.io Bot</a></li>
<li id="menu-item-17602" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17602"><a href="https://goodcrypto.app/hitbtc-trading-bot/">HitBTC Bot</a></li>
<li id="menu-item-15973" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15973"><a href="https://goodcrypto.app/huobi-trading-bot/">Huobi Bot</a></li>
<li id="menu-item-11803" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11803"><a href="https://goodcrypto.app/kucoin-trading-bot/">KuCoin Bot</a></li>
<li id="menu-item-13923" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13923"><a href="https://goodcrypto.app/kraken-trading-bot/">Kraken Bot</a></li>
<li id="menu-item-16185" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16185"><a href="https://goodcrypto.app/okx-trading-bot/">OKX Bot</a></li>
<li id="menu-item-16757" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16757"><a href="https://goodcrypto.app/phemex-trading-bot/">Phemex Bot</a></li>
<li id="menu-item-15029" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15029"><a href="https://goodcrypto.app/poloniex-trading-bot/">Poloniex Bot</a></li>
<li id="menu-item-18089" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-18089"><a href="https://goodcrypto.app/whitebit-bot/">Whitebit Bot</a></li>
<li id="menu-item-10698" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10698"><a href="https://goodcrypto.app/bitcoin-trading-bot/">Bitcoin Bot</a></li>
<li id="menu-item-11281" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11281"><a href="https://goodcrypto.app/doge-trading-bot/">Dogecoin Bot</a></li>
<li id="menu-item-138627" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-138627"><a href="https://goodcrypto.app/ethereum-trading-bot/">Ethereum Bot</a></li>
<li id="menu-item-11282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11282"><a href="https://goodcrypto.app/litecoin-trading-bot/">Litecoin Bot</a></li>
<li id="menu-item-16601" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16601"><a href="https://goodcrypto.app/polygon-trading-bot/">Polygon Bot</a></li>
<li id="menu-item-11995" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11995"><a href="https://goodcrypto.app/ripple-trading-bot/">Ripple Bot</a></li>
<li id="menu-item-11283" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11283"><a href="https://goodcrypto.app/stellar-trading-bot/">Stellar Bot</a></li>
<li id="menu-item-140953" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-140953"><a href="https://goodcrypto.app/popcat-trading-bot/">Popcat Bot</a></li>
<li id="menu-item-140952" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-140952"><a href="https://goodcrypto.app/uniswap-trading-bot/">Uniswap Bot</a></li>
</ul>
</li>
<li id="menu-item-11267" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11267"><a>Trailing Stops</a>
<ul class="sub-menu">
<li id="menu-item-11268" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11268"><a href="https://goodcrypto.app/binance-trailing-stop-order/">Binance Trailing Stop</a></li>
<li id="menu-item-14847" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-14847"><a href="https://goodcrypto.app/binanceus-trailing-stop-order/">Binance.US Trailing Stop</a></li>
<li id="menu-item-16950" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16950"><a href="https://goodcrypto.app/bitfinex-trailing-stop-order/">Bitfinex Trailing Stop</a></li>
<li id="menu-item-16913" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16913"><a href="https://goodcrypto.app/bitmex-trailing-stop-orders/">BitMEX Trailing Stop</a></li>
<li id="menu-item-16912" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16912"><a href="https://goodcrypto.app/bitstamp-trailing-stop-order/">Bitstamp Trailing Stop</a></li>
<li id="menu-item-17631" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17631"><a href="https://goodcrypto.app/bittrex-trailing-stop-order/">Bittrex Trailing Stop</a></li>
<li id="menu-item-12365" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12365"><a href="https://goodcrypto.app/bybit-trailing-stop-orders/">ByBit Trailing Stop</a></li>
<li id="menu-item-14223" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-14223"><a href="https://goodcrypto.app/coinbase-pro-trailing-stop-order/">Coinbase Pro Trailing Stop</a></li>
<li id="menu-item-15622" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15622"><a href="https://goodcrypto.app/coinbase-trailing-stop-order/">Coinbase Trailing Stop</a></li>
<li id="menu-item-17632" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17632"><a href="https://goodcrypto.app/crypto-com-trailing-stop-order/">Crypto.com Trailing Stop</a></li>
<li id="menu-item-12364" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12364"><a href="https://goodcrypto.app/kraken-trailing-stop-order/">Kraken Trailing Stop</a></li>
<li id="menu-item-14215" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-14215"><a href="https://goodcrypto.app/kucoin-trailing-stop-order/">KuСoin Trailing Stop</a></li>
<li id="menu-item-16911" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16911"><a href="https://goodcrypto.app/poloniex-trailing-stop-order/">Poloniex Trailing Stop</a></li>
<li id="menu-item-27066" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-27066"><a href="https://goodcrypto.app/whitebit-trailing-stop-order/">WhiteBIT Trailing Stop</a></li>
</ul>
</li>
<li id="menu-item-11266" class="double-columns-menu menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11266"><a href="#">double-column</a>
<ul class="sub-menu">
<li id="menu-item-15753" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-15753"><a>Stop Loss</a>
<ul class="sub-menu">
<li id="menu-item-15898" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15898"><a href="https://goodcrypto.app/binance-stop-loss-order/">Binance Stop Loss</a></li>
<li id="menu-item-15896" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15896"><a href="https://goodcrypto.app/bybit-stop-loss/">Bybit Stop Loss</a></li>
<li id="menu-item-15758" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15758"><a href="https://goodcrypto.app/coinbase-stop-loss/">Coinbase Stop Loss</a></li>
<li id="menu-item-17313" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-17313"><a href="https://goodcrypto.app/crypto-com-stop-loss-order/">Crypto.com Stop Loss</a></li>
</ul>
</li>
<li id="menu-item-15756" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-15756"><a href="https://goodcrypto.app/good-crypto-signals-the-best-crypto-trading-signals-based-on-technical-indicators/">Signals</a>
<ul class="sub-menu">
<li id="menu-item-15755" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15755"><a href="https://goodcrypto.app/goodcrypto-bearish-signals-the-best-sell-crypto-signals-based-on-technical-analysis/">Bearish Signals</a></li>
<li id="menu-item-15757" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-15757"><a href="https://goodcrypto.app/good-crypto-buy-signals-the-best-crypto-bullish-signals-based-on-technical-indicators/">Buy Signals</a></li>
</ul>
</li>
</ul>
</li>
</ul></div> </div>
</div>
<div class="f-bottom">
<div class="container big">
<div class="rw-1">
<div class="row align-items-center">
<div class="col-12 col-md-auto">
<div class="logo">
<a id="footer-logo" href="https://goodcrypto.app">
<img loading="lazy" id="footer-logo" src="https://goodcrypto.app/wp-content/uploads/2021/08/logo-new.svg" width="273" height="30" alt="logo">
</a>
</div>
</div>
<div class="col-12 col-md-auto">
<div class="for-language pl-xl-5">
<p class="min">Change language:</p>
<div class="languages-widget-header">
<div
	 class="wpml-ls-sidebars-languages-widget-header wpml-ls wpml-ls-legacy-dropdown js-wpml-ls-legacy-dropdown">
<ul>
<li tabindex="0" class="wpml-ls-slot-languages-widget-header wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-first-item wpml-ls-last-item wpml-ls-item-legacy-dropdown">
<a href="#" class="js-wpml-ls-item-toggle wpml-ls-item-toggle">
<span class="wpml-ls-native">EN</span></a>
<ul class="wpml-ls-sub-menu">
</ul>
</li>
</ul>
</div>
</div> </div>
</div>
<div class="col-12 col-md">
<div class="links">
<div class="row justify-content-center">
<div class="col-auto">
<div class="link">
<a href="https://goodcrypto.app/crypto-screener-check-live-cryptocurrency-prices/">
Crypto Screener </a>
</div>
</div>
<div class="col-auto">
<div class="link">
<a href="https://goodcrypto.app/liquidity-checker/">
Liquidity Checker </a>
</div>
</div>
</div>
</div>
</div>
<div class="col-12 col-lg-auto mt-4 mt-lg-0">
<div class="for-social">
<div class="social">
<a id="footer-facebook" rel="nofollow noopener" href="https://www.facebook.com/GoodCryptoApp">
<i id="footer-facebook" class="fab fa-facebook-f"></i>
</a>
<a id="footer-twitter" rel="nofollow noopener" href="https://twitter.com/GoodCryptoApp">
<i id="footer-twitter" class="fab fa-twitter"></i>
</a>
<a id="footer-linkedin" rel="nofollow noopener" href="https://www.linkedin.com/company/goodcrypto/">
<i id="footer-linkedin" class="fab fa-linkedin-in"></i>
</a>
<a id="footer-telegram" rel="nofollow noopener" href="https://t.me/goodcrypto">
<i id="footer-telegram" class="fab fa-telegram-plane"></i>
</a>
<a id="footer-medium" rel="nofollow noopener" href="https://medium.com/cryptto-io">
<i id="footer-medium" class="fab fa-medium-m"></i>
</a>
<a id="footer-reddit" rel="nofollow noopener" href="https://www.reddit.com/r/GoodCrypto">
<i id="footer-reddit" class="fab fa-reddit-alien"></i>
</a>
<a id="footer-youtube" rel="nofollow noopener" href="https://www.youtube.com/channel/UCage4jOHPNVEmMpTH60TDMA">
<i id="footer-youtube" class="fab fa-youtube"></i>
</a>
</div>
</div>
</div>
</div>
</div>
<div class="rw-2 mt-3">
<div class="row align-items-center justify-content-xl-between">
<div class="col-12 col-md-auto">
<p class="supported min">Supported by <a target="_blank" rel="noopener" href="https://rgray.io">RGray</a></p>
</div>
<div class="col-12 col-md-auto mt-2 mt-md-0">
<p class="min">
<a href="https://goodcrypto.app/contact-us/">©2024 GoodC International Ltd. All rights reserved.</a>
|
<a rel="nofollow noopener" href="/privacy/">Privacy policy</a>
</p>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>
<script src='https://goodcrypto.app/wp-content/themes/main-template/plugins/jquery/jquery-3.2.0.min.js?ver=5.5.5' id='jquery-js'></script>
<script id='wpml-cookie-js-extra'>var wpml_cookies={"wp-wpml_current_language":{"value":"en","expires":1,"path":"\/"}};var wpml_cookies={"wp-wpml_current_language":{"value":"en","expires":1,"path":"\/"}};</script>
<script src='https://goodcrypto.app/wp-content/plugins/sitepress-multilingual-cms/res/js/cookies/language-cookie.js?ver=4.6.3' id='wpml-cookie-js'></script>
<script id='contact-form-7-js-extra'>var wpcf7 = {"apiSettings":{"root":"http:\/\/goodcrypto.app\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};</script>
<script src='https://goodcrypto.app/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.3.2' id='contact-form-7-js'></script>
<script id='contactform_js-js-extra'>var wpcf7_override = {"endpoint":"https:\/\/us-central1-crypttoapp.cloudfunctions.net\/contactForm"};</script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/js/contactform.js?ver=5.5.5' id='contactform_js-js'></script>
<script src='//goodcrypto.app/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-dropdown/script.min.js?ver=1' id='wpml-legacy-dropdown-0-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/plugins/bootstrap/js/popper.min.js?ver=5.5.5' id='popper-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/plugins/bootstrap/js/bootstrap.min.js?ver=5.5.5' id='bootstrap-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/plugins/validation/jquery.validate.min.js?ver=5.5.5' id='validate-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/plugins/rangeslider/rangeslider.min.js?ver=5.5.5' id='rangeslider-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/plugins/counter/jquery.plugin.js?ver=5.5.5' id='counter-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/js/analytics.js?ver=5.5.5' id='analytics-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/js/script.js?ver=1735824877' id='my-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/js/trade-contest-report.js?ver=5.5.5' id='trade-contest-report-js'></script>
<script src='https://goodcrypto.app/wp-content/themes/main-template/js/posts-search.js' id='posts-search-js'></script>

<script async>setTimeout(function(){!function(w,d){if(!w.rdt){var p=w.rdt=function(){p.sendEvent?p.sendEvent.apply(p,arguments):p.callQueue.push(arguments)};p.callQueue=[];var t=d.createElement("script");t.src="https://www.redditstatic.com/ads/pixel.js",t.async=!0;var s=d.getElementsByTagName("script")[0];s.parentNode.insertBefore(t,s)}}(window,document);rdt('init','t2_bg5b5cc6');rdt('track','PageVisit');},4000);</script>





<script async>setTimeout(function(){!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','617342545937702');fbq('track','PageView');},4000);</script>
<noscript><img loading="lazy" height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=617342545937702&amp;ev=PageView&amp;noscript=1" /></noscript>

<script data-phast-compiled-js-names="DelayedIFrameLoading/iframe-loader.js">(function phastScripts(phast){phast.scripts=[(function(){phast.config=JSON.parse(atob(phast.config));while(phast.scripts.length){phast.scripts.shift()()}
}),(function(){(function(a,b){typeof exports==="object"&&typeof module!=="undefined"?module.exports=b():typeof define==="function"&&define.amd?define(b):a.ES6Promise=b()})(phast,function(){"use strict";function c(ia){var ja=typeof ia;return ia!==null&&(ja==="object"||ja==="function")}function d(ka){return typeof ka==="function"}var e=void 0;if(Array.isArray){e=Array.isArray}else{e=function(la){return Object.prototype.toString.call(la)==="[object Array]"}}var f=e;var g=0;var h=void 0;var i=void 0;var j=function ma(na,oa){w[g]=na;w[g+1]=oa;g+=2;if(g===2){if(i){i(x)}else{z()}}};function k(pa){i=pa}function l(qa){j=qa}var m=typeof window!=="undefined"?window:undefined;var n=m||{};var o=n.MutationObserver||n.WebKitMutationObserver;var p=typeof self==="undefined"&&typeof process!=="undefined"&&{}.toString.call(process)==="[object process]";var q=typeof Uint8ClampedArray!=="undefined"&&typeof importScripts!=="undefined"&&typeof MessageChannel!=="undefined";function r(){return function(){return process.nextTick(x)}}function s(){if(typeof h!=="undefined"){return function(){h(x)}}return v()}function t(){var ra=0;var sa=new o(x);var ta=document.createTextNode("");sa.observe(ta,{characterData:true});return function(){ta.data=ra=++ra%2}}function u(){var ua=new MessageChannel;ua.port1.onmessage=x;return function(){return ua.port2.postMessage(0)}}function v(){var va=setTimeout;return function(){return va(x,1)}}var w=new Array(1e3);function x(){for(var wa=0;wa<g;wa+=2){var xa=w[wa];var ya=w[wa+1];xa(ya);w[wa]=undefined;w[wa+1]=undefined}g=0}function y(){try{var za=Function("return this")().require("vertx");h=za.runOnLoop||za.runOnContext;return s()}catch(Aa){return v()}}var z=void 0;if(p){z=r()}else if(o){z=t()}else if(q){z=u()}else if(m===undefined&&typeof require==="function"){z=y()}else{z=v()}function A(Ba,Ca){var Da=this;var Ea=new this.constructor(D);if(Ea[C]===undefined){$(Ea)}var Fa=Da._state;if(Fa){var Ga=arguments[Fa-1];j(function(){return W(Fa,Ea,Ga,Da._result)})}else{T(Da,Ea,Ba,Ca)}return Ea}function B(Ha){var Ia=this;if(Ha&&typeof Ha==="object"&&Ha.constructor===Ia){return Ha}var Ja=new Ia(D);P(Ja,Ha);return Ja}var C=Math.random().toString(36).substring(2);function D(){}var E=void 0;var F=1;var G=2;var H={error:null};function I(){return new TypeError("You cannot resolve a promise with itself")}function J(){return new TypeError("A promises callback cannot return that same promise.")}function K(Ka){try{return Ka.then}catch(La){H.error=La;return H}}function L(Ma,Na,Oa,Pa){try{Ma.call(Na,Oa,Pa)}catch(Qa){return Qa}}function M(Ra,Sa,Ta){j(function(Ua){var Va=false;var Wa=L(Ta,Sa,function(Xa){if(Va){return}Va=true;if(Sa!==Xa){P(Ua,Xa)}else{R(Ua,Xa)}},function(Ya){if(Va){return}Va=true;S(Ua,Ya)},"Settle: "+(Ua._label||" unknown promise"));if(!Va&&Wa){Va=true;S(Ua,Wa)}},Ra)}function N(Za,$a){if($a._state===F){R(Za,$a._result)}else if($a._state===G){S(Za,$a._result)}else{T($a,undefined,function(_a){return P(Za,_a)},function(ab){return S(Za,ab)})}}function O(bb,cb,db){if(cb.constructor===bb.constructor&&db===A&&cb.constructor.resolve===B){N(bb,cb)}else{if(db===H){S(bb,H.error);H.error=null}else if(db===undefined){R(bb,cb)}else if(d(db)){M(bb,cb,db)}else{R(bb,cb)}}}function P(eb,fb){if(eb===fb){S(eb,I())}else if(c(fb)){O(eb,fb,K(fb))}else{R(eb,fb)}}function Q(gb){if(gb._onerror){gb._onerror(gb._result)}U(gb)}function R(hb,ib){if(hb._state!==E){return}hb._result=ib;hb._state=F;if(hb._subscribers.length!==0){j(U,hb)}}function S(jb,kb){if(jb._state!==E){return}jb._state=G;jb._result=kb;j(Q,jb)}function T(lb,mb,nb,ob){var pb=lb._subscribers;var qb=pb.length;lb._onerror=null;pb[qb]=mb;pb[qb+F]=nb;pb[qb+G]=ob;if(qb===0&&lb._state){j(U,lb)}}function U(rb){var sb=rb._subscribers;var tb=rb._state;if(sb.length===0){return}var ub=void 0,vb=void 0,wb=rb._result;for(var xb=0;xb<sb.length;xb+=3){ub=sb[xb];vb=sb[xb+tb];if(ub){W(tb,ub,vb,wb)}else{vb(wb)}}rb._subscribers.length=0}function V(yb,zb){try{return yb(zb)}catch(Ab){H.error=Ab;return H}}function W(Bb,Cb,Db,Eb){var Fb=d(Db),Gb=void 0,Hb=void 0,Ib=void 0,Jb=void 0;if(Fb){Gb=V(Db,Eb);if(Gb===H){Jb=true;Hb=Gb.error;Gb.error=null}else{Ib=true}if(Cb===Gb){S(Cb,J());return}}else{Gb=Eb;Ib=true}if(Cb._state!==E){}else if(Fb&&Ib){P(Cb,Gb)}else if(Jb){S(Cb,Hb)}else if(Bb===F){R(Cb,Gb)}else if(Bb===G){S(Cb,Gb)}}function X(Kb,Lb){try{Lb(function Mb(Nb){P(Kb,Nb)},function Ob(Pb){S(Kb,Pb)})}catch(Qb){S(Kb,Qb)}}var Y=0;function Z(){return Y++}function $(Rb){Rb[C]=Y++;Rb._state=undefined;Rb._result=undefined;Rb._subscribers=[]}function _(){return new Error("Array Methods must be provided an Array")}var aa=function(){function Sb(Tb,Ub){this._instanceConstructor=Tb;this.promise=new Tb(D);if(!this.promise[C]){$(this.promise)}if(f(Ub)){this.length=Ub.length;this._remaining=Ub.length;this._result=new Array(this.length);if(this.length===0){R(this.promise,this._result)}else{this.length=this.length||0;this._enumerate(Ub);if(this._remaining===0){R(this.promise,this._result)}}}else{S(this.promise,_())}}Sb.prototype._enumerate=function Vb(Wb){for(var Xb=0;this._state===E&&Xb<Wb.length;Xb++){this._eachEntry(Wb[Xb],Xb)}};Sb.prototype._eachEntry=function Yb(Zb,$b){var _b=this._instanceConstructor;var ac=_b.resolve;if(ac===B){var bc=K(Zb);if(bc===A&&Zb._state!==E){this._settledAt(Zb._state,$b,Zb._result)}else if(typeof bc!=="function"){this._remaining--;this._result[$b]=Zb}else if(_b===ga){var cc=new _b(D);O(cc,Zb,bc);this._willSettleAt(cc,$b)}else{this._willSettleAt(new _b(function(dc){return dc(Zb)}),$b)}}else{this._willSettleAt(ac(Zb),$b)}};Sb.prototype._settledAt=function ec(fc,gc,hc){var ic=this.promise;if(ic._state===E){this._remaining--;if(fc===G){S(ic,hc)}else{this._result[gc]=hc}}if(this._remaining===0){R(ic,this._result)}};Sb.prototype._willSettleAt=function jc(kc,lc){var mc=this;T(kc,undefined,function(nc){return mc._settledAt(F,lc,nc)},function(oc){return mc._settledAt(G,lc,oc)})};return Sb}();function ba(pc){return new aa(this,pc).promise}function ca(qc){var rc=this;if(!f(qc)){return new rc(function(sc,tc){return tc(new TypeError("You must pass an array to race."))})}else{return new rc(function(uc,vc){var wc=qc.length;for(var xc=0;xc<wc;xc++){rc.resolve(qc[xc]).then(uc,vc)}})}}function da(yc){var zc=this;var Ac=new zc(D);S(Ac,yc);return Ac}function ea(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function fa(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}var ga=function(){function Bc(Cc){this[C]=Z();this._result=this._state=undefined;this._subscribers=[];if(D!==Cc){typeof Cc!=="function"&&ea();this instanceof Bc?X(this,Cc):fa()}}Bc.prototype.catch=function Dc(Ec){return this.then(null,Ec)};Bc.prototype.finally=function Fc(Gc){var Hc=this;var Ic=Hc.constructor;return Hc.then(function(Jc){return Ic.resolve(Gc()).then(function(){return Jc})},function(Kc){return Ic.resolve(Gc()).then(function(){throw Kc})})};return Bc}();ga.prototype.then=A;ga.all=ba;ga.race=ca;ga.resolve=B;ga.reject=da;ga._setScheduler=k;ga._setAsap=l;ga._asap=j;function ha(){var Lc=void 0;if(typeof global!=="undefined"){Lc=global}else if(typeof self!=="undefined"){Lc=self}else{try{Lc=Function("return this")()}catch(Oc){throw new Error("polyfill failed because global object is unavailable in this environment")}}var Mc=Lc.Promise;if(Mc){var Nc=null;try{Nc=Object.prototype.toString.call(Mc.resolve())}catch(Pc){}if(Nc==="[object Promise]"&&!Mc.cast){return}}Lc.Promise=ga}ga.polyfill=ha;ga.Promise=ga;return ga});
}),(function(){function murmurhash3_32_gc(a,b){var c,d,e,f,g,h,i,j,k,l;c=a.length&3;d=a.length-c;e=b;g=3432918353;i=461845907;l=0;while(l<d){k=a.charCodeAt(l)&255|(a.charCodeAt(++l)&255)<<8|(a.charCodeAt(++l)&255)<<16|(a.charCodeAt(++l)&255)<<24;++l;k=(k&65535)*g+(((k>>>16)*g&65535)<<16)&4294967295;k=k<<15|k>>>17;k=(k&65535)*i+(((k>>>16)*i&65535)<<16)&4294967295;e^=k;e=e<<13|e>>>19;f=(e&65535)*5+(((e>>>16)*5&65535)<<16)&4294967295;e=(f&65535)+27492+(((f>>>16)+58964&65535)<<16)}k=0;switch(c){case 3:k^=(a.charCodeAt(l+2)&255)<<16;case 2:k^=(a.charCodeAt(l+1)&255)<<8;case 1:k^=a.charCodeAt(l)&255;k=(k&65535)*g+(((k>>>16)*g&65535)<<16)&4294967295;k=k<<15|k>>>17;k=(k&65535)*i+(((k>>>16)*i&65535)<<16)&4294967295;e^=k}e^=a.length;e^=e>>>16;e=(e&65535)*2246822507+(((e>>>16)*2246822507&65535)<<16)&4294967295;e^=e>>>13;e=(e&65535)*3266489909+(((e>>>16)*3266489909&65535)<<16)&4294967295;e^=e>>>16;return e>>>0}phast.hash=murmurhash3_32_gc;
}),(function(){phast.buildServiceUrl=function(a,b){if(a.pathInfo){return appendPathInfo(a.serviceUrl,buildQuery(b))}else{return appendQueryString(a.serviceUrl,buildQuery(b))}};function buildQuery(c){if(typeof c==="string"){return c}var d=[];for(var e in c){if(c.hasOwnProperty(e)){d.push(encodeURIComponent(e)+"="+encodeURIComponent(c[e]))}}return d.join("&")}function appendPathInfo(f,g){var h=btoa(g).replace(/=/g,"").replace(/\//g,"_").replace(/\+/g,"-");var i=j(h+".q.js");return f.replace(/\?.*$/,"").replace(/\/__p__\.js$/,"")+"/"+i;function j(l){return k(k(l).match(/[\s\S]{1,255}/g).join("/"))}function k(m){return m.split("").reverse().join("")}}function appendQueryString(n,o){var p=n.indexOf("?")>-1?"&":"?";return n+p+o}
}),(function(){var Promise=phast.ES6Promise.Promise;phast.ResourceLoader=function(a,b){this.get=function(c){return b.get(c).then(function(d){if(typeof d!=="string"){throw new Error("response should be string")}return d}).catch(function(){var e=a.get(c);e.then(function(f){b.set(c,f)});return e})}};phast.ResourceLoader.RequestParams={};phast.ResourceLoader.RequestParams.FaultyParams={};phast.ResourceLoader.RequestParams.fromString=function(g){try{return JSON.parse(g)}catch(h){return phast.ResourceLoader.RequestParams.FaultyParams}};phast.ResourceLoader.BundlerServiceClient=function(i,j,k){var l=phast.ResourceLoader.BundlerServiceClient.RequestsPack;var m=l.PackItem;var n;this.get=function(q){if(q===phast.ResourceLoader.RequestParams.FaultyParams){return Promise.reject(new Error("Parameters did not parse as JSON"))}return new Promise(function(r,s){if(n===undefined){n=new l(j)}n.add(new m({success:r,error:s},q));setTimeout(o);if(n.toQuery().length>4500){console.log("[Phast] Resource loader: Pack got too big; flushing early...");o()}})};function o(){if(n===undefined){return}var t=n;n=undefined;p(t)}function p(u){var v=phast.buildServiceUrl({serviceUrl:i,pathInfo:k},"service=bundler&"+u.toQuery());var w=function(){console.error("[Phast] Request to bundler failed with status",y.status);console.log("URL:",v);u.handleError()};var x=function(){if(y.status>=200&&y.status<300){u.handleResponse(y.responseText)}else{u.handleError()}};var y=new XMLHttpRequest;y.open("GET",v);y.addEventListener("error",w);y.addEventListener("abort",w);y.addEventListener("load",x);y.send()}};phast.ResourceLoader.BundlerServiceClient.RequestsPack=function(z){var A={};this.getLength=function(){var F=0;for(var G in A){F++}return F};this.add=function(H){var I;if(H.params.token){I="token="+H.params.token}else if(H.params.ref){I="ref="+H.params.ref}else{I=""}if(!A[I]){A[I]={params:H.params,requests:[H.request]}}else{A[I].requests.push(H.request)}};this.toQuery=function(){var J=[],K=[],L="";B().forEach(function(M){var N,O;for(var P in A[M].params){if(P==="cacheMarker"){K.push(A[M].params.cacheMarker);continue}N=z[P]?z[P]:P;if(P==="strip-imports"){O=encodeURIComponent(N)}else if(P==="src"){O=encodeURIComponent(N)+"="+encodeURIComponent(C(A[M].params.src,L));L=A[M].params.src}else{O=encodeURIComponent(N)+"="+encodeURIComponent(A[M].params[P])}J.push(O)}});if(K.length>0){J.unshift("c="+phast.hash(K.join("|"),23045))}return E(J.join("&"))};function B(){return Object.keys(A).sort(function(R,S){return Q(R,S)?1:Q(S,R)?-1:0});function Q(T,U){if(typeof A[T].params.src!=="undefined"&&typeof A[U].params.src!=="undefined"){return A[T].params.src>A[U].params.src}return T>U}}function C(V,W){var X=0,Y=Math.pow(36,2)-1;while(X<W.length&&V[X]===W[X]){X++}X=Math.min(X,Y);return D(X)+""+V.substr(X)}function D(Z){var $=["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];var _=Z%36;var aa=Math.floor((Z-_)/36);return $[aa]+$[_]}function E(ba){if(!/(^|&)s=/.test(ba)){return ba}return ba.replace(/(%..)|([A-M])|([N-Z])/gi,function(ca,da,ea,fa){if(da){return ca}return String.fromCharCode(ca.charCodeAt(0)+(ea?13:-13))})}this.handleResponse=function(ga){try{var ha=JSON.parse(ga)}catch(ja){this.handleError();return}var ia=B();if(ha.length!==ia.length){console.error("[Phast] Requested",ia.length,"items from bundler, but got",ha.length,"response(s)");this.handleError();return}ha.forEach(function(ka,la){if(ka.status===200){A[ia[la]].requests.forEach(function(ma){ma.success(ka.content)})}else{A[ia[la]].requests.forEach(function(na){na.error(new Error("Got from bundler: "+JSON.stringify(ka)))})}})}.bind(this);this.handleError=function(){for(var oa in A){A[oa].requests.forEach(function(pa){pa.error()})}}};phast.ResourceLoader.BundlerServiceClient.RequestsPack.PackItem=function(qa,ra){this.request=qa;this.params=ra};phast.ResourceLoader.IndexedDBStorage=function(sa){var ta=phast.ResourceLoader.IndexedDBStorage;var ua=ta.logPrefix;var va=ta.requestToPromise;var wa;Ba();this.get=function(Ca){return xa("readonly").then(function(Da){return va(Da.get(Ca)).catch(ya("reading from store"))})};this.store=function(Ea){return xa("readwrite").then(function(Fa){return va(Fa.put(Ea)).catch(ya("writing to store"))})};this.clear=function(){return xa("readwrite").then(function(Ga){return va(Ga.clear())})};this.iterateOnAll=function(Ha){return xa("readonly").then(function(Ia){return za(Ha,Ia.openCursor()).catch(ya("iterating on all"))})};function xa(Ja){return wa.get().then(function(Ka){try{return Ka.transaction(sa.storeName,Ja).objectStore(sa.storeName)}catch(La){console.error(ua,"Could not open store; recreating database:",La);Aa();throw La}})}function ya(Ma){return function(Na){console.error(ua,"Error "+Ma+":",Na);Aa();throw Na}}function za(Oa,Pa){return new Promise(function(Qa,Ra){Pa.onsuccess=function(Sa){var Ta=Sa.target.result;if(Ta){Oa(Ta.value);Ta.continue()}else{Qa()}};Pa.onerror=Ra})}function Aa(){var Ua=wa.dropDB().then(Ba);wa={get:function(){return Promise.reject(new Error("Database is being dropped and recreated"))},dropDB:function(){return Ua}}}function Ba(){wa=new phast.ResourceLoader.IndexedDBStorage.Connection(sa)}};phast.ResourceLoader.IndexedDBStorage.logPrefix="[Phast] Resource loader:";phast.ResourceLoader.IndexedDBStorage.requestToPromise=function(Va){return new Promise(function(Wa,Xa){Va.onsuccess=function(){Wa(Va.result)};Va.onerror=function(){Xa(Va.error)}})};phast.ResourceLoader.IndexedDBStorage.ConnectionParams=function(){this.dbName="phastResourcesCache";this.dbVersion=1;this.storeName="resources"};phast.ResourceLoader.IndexedDBStorage.StoredResource=function(Ya,Za){this.token=Ya;this.content=Za};phast.ResourceLoader.IndexedDBStorage.Connection=function($a){var _a=phast.ResourceLoader.IndexedDBStorage.logPrefix;var ab=phast.ResourceLoader.IndexedDBStorage.requestToPromise;var bb;this.get=cb;this.dropDB=db;function cb(){if(!bb){bb=eb($a)}return bb}function db(){return cb().then(function(gb){console.error(_a,"Dropping DB");gb.close();bb=null;return ab(window.indexedDB.deleteDatabase($a.dbName))})}function eb(hb){if(typeof window.indexedDB==="undefined"){return Promise.reject(new Error("IndexedDB is not available"))}var ib=window.indexedDB.open(hb.dbName,hb.dbVersion);ib.onupgradeneeded=function(){fb(ib.result,hb)};return ab(ib).then(function(jb){jb.onversionchange=function(){console.debug(_a,"Closing DB");jb.close();if(bb){bb=null}};return jb}).catch(function(kb){console.log(_a,"IndexedDB cache is not available. This is usually due to using private browsing mode.");throw kb})}function fb(lb,mb){lb.createObjectStore(mb.storeName,{keyPath:"token"})}};phast.ResourceLoader.StorageCache=function(nb,ob){var pb=phast.ResourceLoader.IndexedDBStorage.StoredResource;this.get=function(xb){return sb(rb(xb))};this.set=function(yb,zb){return tb(rb(yb),zb,false)};var qb=null;function rb(Ab){return JSON.stringify(Ab)}function sb(Bb){return ob.get(Bb).then(function(Cb){if(Cb){return Promise.resolve(Cb.content)}return Promise.resolve()})}function tb(Db,Eb,Fb){return wb().then(function(Gb){var Hb=Eb.length+Gb;if(Hb>nb.maxStorageSize){return Fb||Eb.length>nb.maxStorageSize?Promise.reject(new Error("Storage quota will be exceeded")):ub(Db,Eb)}qb=Hb;var Ib=new pb(Db,Eb);return ob.store(Ib)})}function ub(Jb,Kb){return vb().then(function(){return tb(Jb,Kb,true)})}function vb(){return ob.clear().then(function(){qb=0})}function wb(){if(qb!==null){return Promise.resolve(qb)}var Lb=0;return ob.iterateOnAll(function(Mb){Lb+=Mb.content.length}).then(function(){qb=Lb;return Promise.resolve(qb)})}};phast.ResourceLoader.StorageCache.StorageCacheParams=function(){this.maxStorageSize=4.5*1024*1024};phast.ResourceLoader.BlackholeCache=function(){this.get=function(){return Promise.reject()};this.set=function(){return Promise.reject()}};phast.ResourceLoader.make=function(Nb,Ob,Pb){var Qb=Sb();var Rb=new phast.ResourceLoader.BundlerServiceClient(Nb,Ob,Pb);return new phast.ResourceLoader(Rb,Qb);function Sb(){var Tb=window.navigator.userAgent;if(/safari/i.test(Tb)&&!/chrome|android/i.test(Tb)){console.log("[Phast] Not using IndexedDB cache on Safari");return new phast.ResourceLoader.BlackholeCache}else{var Ub=new phast.ResourceLoader.IndexedDBStorage.ConnectionParams;var Vb=new phast.ResourceLoader.IndexedDBStorage(Ub);var Wb=new phast.ResourceLoader.StorageCache.StorageCacheParams;return new phast.ResourceLoader.StorageCache(Wb,Vb)}}};
}),(function(){var Promise=phast.ES6Promise;phast.ResourceLoader.instance=phast.ResourceLoader.make(phast.config.resourcesLoader.serviceUrl,phast.config.resourcesLoader.shortParamsMappings,phast.config.resourcesLoader.pathInfo);phast.forEachSelectedElement=function(a,b){Array.prototype.forEach.call(window.document.querySelectorAll(a),b)};phast.once=function(c){var d=false;return function(){if(!d){d=true;c.apply(this,Array.prototype.slice(arguments))}}};phast.on=function(e,f){return new Promise(function(g){e.addEventListener(f,g)})};phast.wait=function(h){return new Promise(function(i){setTimeout(i,h)})};phast.on(document,"DOMContentLoaded").then(function(){var j,k;function l(n){return n&&n.nodeType===8&&/^\s*\[Phast\]/.test(n.textContent)}function m(o){while(o){if(l(o)){return o}o=o.nextSibling}return false}k=m(document.documentElement.nextSibling);if(k===false){k=m(document.body.firstChild)}if(k){j=k.textContent.replace(/^\s+|\s+$/g,"").split("\n");console.groupCollapsed(j.shift());console.log(j.join("\n"));console.groupEnd()}});phast.on(document,"DOMContentLoaded").then(function(){var p=performance.timing;var q=[];q.push(["Downloading phases:"]);q.push(["  Look up hostname in DNS            + %s ms",t(p.domainLookupEnd-p.fetchStart)]);q.push(["  Establish connection               + %s ms",t(p.connectEnd-p.domainLookupEnd)]);q.push(["  Send request                       + %s ms",t(p.requestStart-p.connectEnd)]);q.push(["  Receive first byte                 + %s ms",t(p.responseStart-p.requestStart)]);q.push(["  Download page                      + %s ms",t(p.responseEnd-p.responseStart)]);q.push([""]);q.push(["Totals:"]);q.push(["  Time to first byte                   %s ms",t(p.responseStart-p.fetchStart)]);q.push(["    (since request start)              %s ms",t(p.responseStart-p.requestStart)]);q.push(["  Total request time                   %s ms",t(p.responseEnd-p.fetchStart)]);q.push(["    (since request start)              %s ms",t(p.responseEnd-p.requestStart)]);q.push([" "]);var r=[];var s=[];q.forEach(function(u){r.push(u.shift());s=s.concat(u)});console.groupCollapsed("[Phast] Client-side performance metrics");console.log.apply(console,[r.join("\n")].concat(s));console.groupEnd();function t(v){v=""+v;while(v.length<4){v=" "+v}return v}});
}),(function(){window.addEventListener("load",function(){window.setTimeout(loadIframes,30)});function loadIframes(){phast.forEachSelectedElement("iframe[data-phast-src]",function(a){var b=a.getAttribute("data-phast-src");a.removeAttribute("data-phast-src");if(a.getAttribute("src")==="about:blank"){a.setAttribute("src",b)}})}
})];(phast.scripts.shift())();})({"config":"eyJyZXNvdXJjZXNMb2FkZXIiOnsic2VydmljZVVybCI6Imh0dHA6Ly9jbS5jcnlwdHRvLmlvL3dwLWNvbnRlbnQvcGx1Z2lucy9waGFzdHByZXNzL3BoYXN0LnBocD8iLCJzaG9ydFBhcmFtc01hcHBpbmdzIjp7InNyYyI6InMiLCJzdHJpcC1pbXBvcnRzIjoiaSIsImNhY2hlTWFya2VyIjoiYyIsInRva2VuIjoidCIsImlzU2NyaXB0IjoiaiIsInJlZiI6InIifSwicGF0aEluZm8iOmZhbHNlfX0="});</script></body>
</html>
<!-- [Phast] Document optimized in 17ms -->
